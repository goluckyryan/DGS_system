# From Mark Rivers.
# He was doing some testing with callbacks and ran into some
# problems that he wanted me to look at.  While I was looking
# he solved his problem.
#
from CaChannel import *
import sys

class pv_test(CaChannel):
   def __init__(self, pvname=None):
      # Invoke the base class initialization
      CaChannel.__init__(self, pvname)

   def getCallBack(self, epicsArgs, userArgs):
      #print 'getCallback'
      pass

def otherCallBack(epicsArgs, userArgs):
      #print 'otherCallback'
      pass

for i in range(10000):
   # Replace with any PV here.
   c=pv_test('CTL_PROC_07/MEM')

#   c=pv_test('13GE1:med:mca1.NUSE')
#   c=CaChannel('13GE1:med:mca1.NUSE')
   c.searchw()

   # Uncomment one of the following 3 lines.  
   #
   # If the first line is used, setting the callback to the getCallback in 
   # the pv_test class, then there are unreleased resources: the size of the 
   # python task grows without limit and the free memory on the IOC 
   # decreases until it disconnects from channel access.  The IOC memory
   # consumption is about 270 bytes per loop.
   #
   # If the second line is used, passing the pv_test object as the userArg,
   # to otherCallback, the same thing happens.  The same thing also happens if
   # "c" is a CaChannel object, rather than a "pv_test" object (uncomment line
   # above).
   #
   # If the third line is used, calling otherCallBack with no reference to
   # the pv_test object, then everything is fine.  However, this seems pretty
   # useless, since there is then no way for the callback routine to know 
   # what PV the callback was for!

   prerefcount = sys.getrefcount(c)
   c.add_masked_array_event(None, None, ca.DBE_VALUE, c.getCallBack, 0)
#   c.add_masked_array_event(None, None, ca.DBE_VALUE, otherCallBack, c)
#   c.add_masked_array_event(None, None, ca.DBE_VALUE, otherCallBack)

   c.pend_event(.01)
   print 'i=',i, 'prerefcount =', prerefcount, 'postrefcount =', sys.getrefcount(c)
   c.clear_event()
   print 'refcount =', sys.getrefcount(c)
   del c
   #c=0  # This deletes the pv_test object, calling destructor for CaChannel
        # thus calling ca_clear_channel and clear_event 
